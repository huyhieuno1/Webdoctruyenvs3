package group1.service;

import group1.model.Account;

public interface IAccountService {

	void save(Account dg);
	void update(Account dg);
	void delete(Account dg);
}
