package group1.service;

import group1.model.DanhGia;

public interface IDanhGiaService {

	void save(DanhGia dg);
}
