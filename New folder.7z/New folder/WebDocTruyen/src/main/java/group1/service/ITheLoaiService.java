package group1.service;

import java.util.List;

import group1.model.TheLoai;

public interface ITheLoaiService {

	List<TheLoai> getList();
	
}
