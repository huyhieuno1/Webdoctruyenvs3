package group1.service;

import group1.model.DanhGia;

public class DanhGiaServiceimpl implements IDanhGiaService{

	@Override
	public void save(DanhGia dg) {
		// TODO Auto-generated method stub
		
	}

}
